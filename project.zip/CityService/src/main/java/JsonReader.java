import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;


import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONException;
import org.apache.commons.io.FileUtils;

public class JsonReader {

	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static JSONArray readJsonFromUrl(String url) throws IOException, JSONException {
		InputStream is = new URL(url).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			String jsonText = readAll(rd);
			JSONArray jsonArray = new JSONArray(jsonText);
			return jsonArray;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		finally {
			is.close();
		}
	}

	public static void generateCSVfromJson(JSONArray jsonArray)
	{
		File file=new File("CityDetails.csv");
		String csv = CDL.toString(jsonArray);
		try {
			FileUtils.writeStringToFile(file, csv);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("ERROR :"+e.getMessage());
			System.exit(-1);
		}
		System.out.println("CSV file created with filename : CityDetails.csv");
	}
	public static void main(String[] args) throws IOException, JSONException {
		if( args.length == 0)
		{
			System.out.println("ERROR : City name not given");
			System.exit(-1);
		}
		try
		{
			String city = args[0];
			JSONArray jsonArray = readJsonFromUrl("http://api.goeuro.com/api/v2/position/suggest/en/"+city);
			generateCSVfromJson(jsonArray);
		}
		catch(Exception e)
		{
			System.out.println("ERROR :"+e.getMessage());
		}
	}
}