import static org.junit.Assert.*;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Test;



public class CityTest {

	@Test
	public void testForNoResult()
	{

		try {
			assertEquals(0, JsonReader.readJsonFromUrl("http://api.goeuro.com/api/v2/position/suggest/en/xyz").length());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testForValidCity()
	{
		try {
			assertNotEquals(0, JsonReader.readJsonFromUrl("http://api.goeuro.com/api/v2/position/suggest/en/berlin").length());
			assertNotEquals(0, JsonReader.readJsonFromUrl("http://api.goeuro.com/api/v2/position/suggest/en/Hyderabad").length());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


}
